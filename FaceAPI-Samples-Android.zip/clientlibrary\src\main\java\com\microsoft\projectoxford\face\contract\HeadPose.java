// Copyright (c) Microsoft. All rights reserved.

package com.microsoft.projectoxford.face.contract;

public class HeadPose {
    public float roll;

    public float yaw;

    public float pitch;
}
