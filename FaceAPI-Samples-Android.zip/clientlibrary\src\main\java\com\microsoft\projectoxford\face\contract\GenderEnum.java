// Copyright (c) Microsoft. All rights reserved.

package com.microsoft.projectoxford.face.contract;

public enum GenderEnum {
    unknown,

    male,

    female,
}
