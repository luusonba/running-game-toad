// Copyright (c) Microsoft. All rights reserved.

package com.microsoft.projectoxford.face.contract;

public class Gender {
    public GenderEnum gender;

    public double confidence;
}
