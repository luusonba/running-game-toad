// Copyright (c) Microsoft. All rights reserved.

package com.microsoft.projectoxford.face.contract;

public class PersonGroup {
    public String personGroupId;

    public String name;

    public String userData;
}
