// Copyright (c) Microsoft. All rights reserved.

package com.microsoft.projectoxford.face.contract;

import java.util.UUID;

public class SimilarFace {
    public UUID faceId;

    public float confidence;
}
