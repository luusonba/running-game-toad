// Copyright (c) Microsoft. All rights reserved.

package com.microsoft.projectoxford.face.contract;

public class VerifyResult {
    public boolean isIdentical;

    public double confidence;
}
