// Copyright (c) Microsoft. All rights reserved.

package com.microsoft.projectoxford.face.contract;

public class FaceRectangle {
    public int width;

    public int height;

    public int left;

    public int top;
}
