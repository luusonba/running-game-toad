// Copyright (c) Microsoft. All rights reserved.

package com.microsoft.projectoxford.face.contract;

public class FaceAttribute {
    public double age;

    public GenderEnum gender;

    public HeadPose headPose;
}
