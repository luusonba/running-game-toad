// Copyright (c) Microsoft. All rights reserved.

package com.microsoft.projectoxford.face.rest;

public class ServiceCallException {
    String code;
    String message;
}
