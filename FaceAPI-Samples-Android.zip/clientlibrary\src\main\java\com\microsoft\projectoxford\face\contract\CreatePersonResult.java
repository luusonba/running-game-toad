// Copyright (c) Microsoft. All rights reserved.

package com.microsoft.projectoxford.face.contract;

import java.util.UUID;

public class CreatePersonResult {
    public UUID personId;
}
