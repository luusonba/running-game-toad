// Copyright (c) Microsoft. All rights reserved.

package com.microsoft.projectoxford.face.contract;

import java.util.List;
import java.util.UUID;

public class GroupResult {
    public List<List<UUID> > groups;

    public List<UUID> messyGroup;
}
