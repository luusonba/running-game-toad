// Copyright (c) Microsoft. All rights reserved.

package com.microsoft.projectoxford.face.contract;

import java.util.UUID;

public class Candidate {
    public UUID personId;

    public double confidence;
}
