package com.microsoft.projectoxford.vision.contract;

public class Adult {
    public boolean isAdultContent;

    public boolean isRacyContent;

    public float adultScore;

    public float racyScore;
}
