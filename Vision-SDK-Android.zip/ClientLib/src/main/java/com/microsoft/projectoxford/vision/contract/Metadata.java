package com.microsoft.projectoxford.vision.contract;

public class Metadata {
    public int width;

    public int height;

    public String format;

}
