package com.microsoft.projectoxford.vision.contract;

public class LanguageCodes {
    public static String AutoDetect = "unk";

    public static String ChineseSimplified = "zh-Hans";

    public static String ChineseTraditional = "zh-Hant";

    public static String Czech = "cs";

    public static String Danish = "da";

    public static String Dutch = "nl";

    public static String English = "en";

    public static String Finnish = "fi";

    public static String French = "fr";

    public static String German = "de";

    public static String Greek = "el";

    public static String Hungarian = "hu";

    public static String Italian = "it";

    public static String Japanese = "ja";

    public static String Korean = "ko";

    public static String Norwegian = "nb";

    public static String Polish = "pl";

    public static String Portuguese = "pt";

    public static String Russian = "ru";

    public static String Spanish = "es";

    public static String Swedish = "sv";

    public static String Turkish= "tr";
}
