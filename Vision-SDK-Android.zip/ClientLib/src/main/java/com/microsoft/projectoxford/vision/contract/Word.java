package com.microsoft.projectoxford.vision.contract;

public class Word {
    public String boundingBox; //e.g. "boundingBox":"66, 66, 33, 18",

    public String text;
}
