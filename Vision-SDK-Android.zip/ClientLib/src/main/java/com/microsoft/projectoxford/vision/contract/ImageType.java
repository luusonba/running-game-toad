package com.microsoft.projectoxford.vision.contract;

public class ImageType {
    public int clipArtType;

    public int lineDrawingType;
}
