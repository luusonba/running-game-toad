package com.microsoft.projectoxford.vision.contract;

public class Face {
    public int age;

    public GenderEnum gender;

    public float genderScore;

    public FaceRectangle faceRectangle;
}
