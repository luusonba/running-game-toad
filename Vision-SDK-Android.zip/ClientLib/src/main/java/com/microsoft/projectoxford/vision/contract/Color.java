package com.microsoft.projectoxford.vision.contract;

import java.util.List;

public class Color {
    public String accentColor;

    public String domainantColorForeground;

    public String domainantColorBackground;

    public List<String> domainantColors;

    public boolean isBWImg;
}
