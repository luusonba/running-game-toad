package com.microsoft.projectoxford.vision.contract;

public class FaceRectangle {
    public int width;

    public int height;

    public int left;

    public int top;
}
