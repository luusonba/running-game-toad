package com.microsoft.projectoxford.vision.contract;

public class Category {
    public String name;

    public float score;
}
