package com.microsoft.projectoxford.vision.contract;

public enum GenderEnum {
    Unknown,

    Male,

    Female
}
