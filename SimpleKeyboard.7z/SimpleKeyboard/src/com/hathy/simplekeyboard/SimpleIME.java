package com.hathy.simplekeyboard;
import android.graphics.drawable.Drawable;
import android.inputmethodservice.InputMethodService;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.KeyboardView;
import android.inputmethodservice.KeyboardView.OnKeyboardActionListener;
import android.media.AudioManager;
import android.text.Html;
import android.text.Html.ImageGetter;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ImageSpan;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputConnection;

public class SimpleIME extends InputMethodService
	implements OnKeyboardActionListener{
	
	private KeyboardView kv;
	private Keyboard keyboard;
	
	private boolean caps = false;
	
	@Override
	public View onCreateInputView() {
		kv = (KeyboardView)getLayoutInflater().inflate(R.layout.keyboard, null);
		keyboard = new Keyboard(this, R.xml.qwerty);
		kv.setKeyboard(keyboard);
		kv.setOnKeyboardActionListener(this);
		kv.invalidateAllKeys();
		return kv;
	}

	@Override
	public void onKey(int primaryCode, int[] keyCodes) {		
		InputConnection ic = getCurrentInputConnection();
		playClick(primaryCode);
		switch(primaryCode){
		case Keyboard.KEYCODE_DELETE :
			ic.deleteSurroundingText(1, 0);
			break;
		case Keyboard.KEYCODE_SHIFT:
			caps = !caps;
			keyboard.setShifted(caps);
			kv.invalidateAllKeys();
			break;
		case Keyboard.KEYCODE_DONE:
			ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER));
			break;
		default:
			char code = (char)primaryCode;
			if(Character.isLetter(code) && caps){
				code = Character.toUpperCase(code);
			}
			
			ImageGetter imageGetter = new ImageGetter() 
            {
                public Drawable getDrawable(String source) {
                    Drawable d = getResources().getDrawable(R.drawable.ic_launcher);
                    d.setBounds(0, 0, d.getIntrinsicWidth(), d.getIntrinsicHeight());
                    return d;
                }
            };

            Spanned cs = Html.fromHtml("<img src='" + getResources().getDrawable(R.drawable.ic_launcher) + "'/>", imageGetter, null);
                       
/*            ic.beginBatchEdit();


            ic.commitText((CharSequence)"[\0x0031]", 1);

            ic.endBatchEdit();*/
            
            Drawable drawable = getResources().getDrawable(R.drawable.ic_launcher);
    		drawable.setBounds(0, 0, drawable.getIntrinsicWidth(),
    				drawable.getIntrinsicHeight());
    		SpannableString spannable = new SpannableString("" + "[smile]");
    		ImageSpan span = new ImageSpan(drawable, ImageSpan.ALIGN_BASELINE);
    		spannable.setSpan(span, 0,
    				0 + "[smile]".length(),
    				Spannable.SPAN_INCLUSIVE_EXCLUSIVE);
    		
    		ic.commitText(spannable, 1);
            
			//ic.commitText(String.valueOf(code),1);					
		}
	}
	
	private void playClick(int keyCode){
		AudioManager am = (AudioManager)getSystemService(AUDIO_SERVICE);
		switch(keyCode){
		case 32: 
			am.playSoundEffect(AudioManager.FX_KEYPRESS_SPACEBAR);
			break;
		case Keyboard.KEYCODE_DONE:
		case 10: 
			am.playSoundEffect(AudioManager.FX_KEYPRESS_RETURN);
			break;
		case Keyboard.KEYCODE_DELETE:
			am.playSoundEffect(AudioManager.FX_KEYPRESS_DELETE);
			break;				
		default: am.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD);
		}		
	}

	@Override
	public void onPress(int primaryCode) {
	}

	@Override
	public void onRelease(int primaryCode) { 			
	}

	@Override
	public void onText(CharSequence text) {		
	}

	@Override
	public void swipeDown() {	
	}

	@Override
	public void swipeLeft() {
	}

	@Override
	public void swipeRight() {
	}

	@Override
	public void swipeUp() {
	}
}
