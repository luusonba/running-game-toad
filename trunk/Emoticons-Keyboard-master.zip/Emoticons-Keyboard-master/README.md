Emoticons-Keyboard
==================

[![Android Arsenal](https://img.shields.io/badge/Android%20Arsenal-Emoticons--Keyboard-brightgreen.svg?style=flat)](https://android-arsenal.com/details/3/1005)

A custom keyboard (dialog) for emoticons for android chatting application.

*It uses :*
- Dialog box for keyboard
- Viewpager and gridview for drawer
- spannable strings for showing emoticons

Usage
-----
This project is not a library. It is just a common android application in which i have just try to implement a keyboard (actually a dialog box) for adding smileys in texts.


ScreenShots
-----------

![Screenshot 1](/s1.png "")


![Screenshot 2](/s2.png "")


![Screenshot 3](/s3.png "")

Copyright (c) 2013 Chirag Jain

